class FolderDto(object):
    def __init__(self):
        self.folder_id = ""
        self.folder_name = ""
        self.rules = []