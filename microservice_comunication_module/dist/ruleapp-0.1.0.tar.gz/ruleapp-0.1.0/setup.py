import setuptools

setuptools.setup(
    name="ruleapp",
    version="0.1.0",
    author="Giovanni Di Martino",
    author_email="giovanni.dimartino1994@gmail.com",
    description="ruleapp dto library",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    packages=setuptools.find_packages()
)