class UserDto(object):
    def __init__(self):
        self.user_id = ""
        self.sensors = []
        self.switches = []
        self.rules = []
        self.folders = []
