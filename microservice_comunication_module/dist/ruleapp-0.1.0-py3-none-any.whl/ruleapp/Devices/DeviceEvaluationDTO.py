
class DeviceEvaluation(object):
    def __init__(self):
        self.user_id = ""
        self.device_id = ""
        self.measure = ""
        self.rules = []
        self.type = ""
